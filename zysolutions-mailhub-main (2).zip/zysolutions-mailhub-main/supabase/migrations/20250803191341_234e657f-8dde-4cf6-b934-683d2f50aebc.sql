-- Deshabilitar RLS temporalmente para development
ALTER TABLE public.email_templates DISABLE ROW LEVEL SECURITY;